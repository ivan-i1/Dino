﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Linq;

using UnityEditor;
using UnityEngine;

namespace Tiled2Unity
{
    partial class ImportTiled2Unity : IDisposable
    {
        public void Dispose()
        {
        }
    }
}
